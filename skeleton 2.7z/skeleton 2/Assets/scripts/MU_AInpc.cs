﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MU_AInpc : MonoBehaviour
{


    /// <summary>
    /// //what do i need to do
    /// </summary>
    /// 1. make an npc bullet gameobject.
    /// 2. make an enum/integer for states
    /// 3. make the npc starting state to roam
    /// 4. set the npc state to chase when (the pc) x position is less then (distance to chase pc variable).
    /// 5. if the state is chase, move towards the pc from your current position.
    /// 6. if the distance from the pc, is less than 2. then create a bullet at your transform, push the bullet using (npc bullet speed)
    /// 7. edit pc collision, set the player transform position to 0, on collision with bullets.


    public GameObject pc;
    // public string startstate;
    public string nextstate;
    public string currentstate;
    public float chasespeed;
    public float chasedistance;
    public float attackdistance;
    public static float attackdist;
    public static bool pcistotheright = false;
    public static bool pcistotheleft = false;
    public float cooldwontime;

    //test booleans
    public bool iammovingright = false;
    public bool iamworking = false;
    public bool canshoot = false;
    public GameObject enemybullet;
    //public mu_npcmove npcscript;
    // Use this for initialization
    void Start()
    {
        pc = GameObject.Find("pc");
        //GameObject.FindGameObjectWithTag("npc").GetComponent<mu_npcmove>().enabled = false;
        currentstate = "roam";
        InvokeRepeating("attacker", 1f, cooldwontime);
    }

    // Update is called once per frame
    void Update()
    {
        attackdist = attackdistance;
        if (pc.transform.position.x - this.transform.position.x < chasedistance)
        {
            pcistotheright = true;
        }
        if (this.transform.position.x - pc.transform.position.x > chasedistance)
        {
            pcistotheleft = true;
        }
        changestates();
        actonstatechanges();
        // }

    }

    void changestates()
    {
        if (currentstate == "roam" && Vector2.Distance(pc.transform.position, this.transform.position) < chasedistance)//|| currentstate == "roam" && Vector2.Distance(pc.transform.position, this.transform.position) >5)
        {
            currentstate = "chase";
            print("chaserange");
        }
        else if (currentstate == "chase" && Vector2.Distance(pc.transform.position, this.transform.position) < attackdistance)
        {
            currentstate = "attack";
            print("attackrange");
        }
        else if (currentstate == "attack" && Vector2.Distance(pc.transform.position, this.transform.position) > attackdistance)
        {
            currentstate = "chase";
        }
        else if (currentstate == "chase" && Vector2.Distance(pc.transform.position, this.transform.position) > chasedistance)
        {
            currentstate = "roam";
            print("roam");
            if(GameObject.FindGameObjectWithTag("npc").GetComponent<mu_npcmove>().enabled == false)
            {
                GameObject.FindGameObjectWithTag("npc").GetComponent<mu_npcmove>().enabled = true;
            }
        }
    }
    void attacking()
    {
        //check if pc is to the right or the left
        // if pc is to the right or left create bullet
        //
        iamworking=true;
        GameObject.Instantiate(enemybullet, transform.position, transform.rotation);
    }
    
    void actonstatechanges()
    {
        if (currentstate == "chase")
        {
            GameObject.FindGameObjectWithTag("npc").GetComponent<mu_npcmove>().enabled = false;
            //if pc is to your left
            if (pcistotheleft)
            {
                this.transform.Translate(Vector3.left * chasespeed);
            }
            else if (pcistotheright)
            {
                this.transform.Translate(Vector3.right * chasespeed);
            }
            //    if (this.transform.position.x - pc.transform.position.x < chasedistance)
            //    {
            //        this.transform.Translate(Vector3.left * chasespeed);
            //    }
            //        //if pc is to your right
            //    else if (pc.transform.position.x - this.transform.position.x < chasedistance)
            //    {
            //        this.transform.Translate(Vector3.right * chasespeed);
            //        iammovingright = true;
            //    }
            //}  
        }
        else if (currentstate == "attack")
        {
            GameObject.FindGameObjectWithTag("npc").GetComponent<mu_npcmove>().enabled = false;
            canshoot = true;
        }
    }
    void attacker()
    {
        if(canshoot)
        {
            attacking();
        }
    }
    
}
