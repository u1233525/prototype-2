﻿using UnityEngine;
using System.Collections;

public class mu_npcmove : MonoBehaviour
{
    public float movementspeed;
    private float leftspeed;
    public float startposition;
    public float movelimit;
    // public float leftlimit;

    // Use this for initialization
    void Start()
    {
        startposition = this.transform.position.x;
        //movementspeed=-leftspeed;
        leftspeed = -movementspeed;
    }

    // Update is called once per frame
    void Update()
    {
        movenpc();
    }
    void movenpc()
    {
        if (transform.position.x - startposition >= movelimit)
        {
            movementspeed = leftspeed;
        }
        else if (transform.position.x <= startposition - movelimit)
        {
            movementspeed = -leftspeed;
        }
        transform.Translate(movementspeed * Time.deltaTime, 0, 0);
    }
}
