﻿using UnityEngine;
using System.Collections;

public class MU_shooting : MonoBehaviour
{
    public GameObject bullet;
    public Vector3 positionleft;
    public Vector3 positionright;
    private GameObject pc;
    
    // Use this for initialization
    void Start()
    {
        pc = GameObject.FindGameObjectWithTag("pc");
        //positionleft = new Vector3(transform.position.x - 0.7f, 0,0);
        //positionright= new Vector3(transform.position.x + 0.7f, 0, 0);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.A))
        {
            if(mu_pcmove.directionfacing==1)
            {
                shootleft();
            }
            else if(mu_pcmove.directionfacing==2)
            {
                shootright();
            }
        }
    }
    void shootleft()
    {
        GameObject.Instantiate(bullet, new Vector3(pc.transform.position.x-0.7f,0,0), Quaternion.identity);
    }
    void shootright()
    {
        GameObject.Instantiate(bullet, new Vector3(pc.transform.position.x + 0.7f, 0, 0), Quaternion.identity);
    }
}
