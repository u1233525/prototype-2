﻿using UnityEngine;
using System.Collections;

public class mu_pcmove : MonoBehaviour
{
    public GameObject pc;
   // public GameObject bullet;
    public bool canjump;
    public float movementspeed;
    public float jumpspeed;
    public bool pcfacingright;
    public bool pcfcingleft;
    public float bulletspeed;
    public static int directionfacing = 0;
    // Use this for initialization
    void Start()
    {
        canjump = true;
        pc = GameObject.Find("pc");
    }

    // Update is called once per frame

    void Update()
    {
        move();
        //shoot();
    }

    void move()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow) && canjump == true)
        {
            pc.transform.position += new Vector3(0, jumpspeed, 0);
            canjump = false;
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            //pcfacingright = true;
            //pcfcingleft = false;
            pc.transform.position += new Vector3(movementspeed, 0, 0);
            directionfacing = 2;

        }
        else if (Input.GetKey(KeyCode.LeftArrow))
        {
            //pcfacingright = false;
            //pcfcingleft = true;
            //pc.transform.Rotate(new Vector3(0, 180, 0));
            pc.transform.position -= new Vector3(movementspeed, 0, 0);
            directionfacing = 1;

        }
    }
    //void shoot()
    //{
        
    //        if (Input.GetKeyDown(KeyCode.A))
    //        //{
    //        //if (pcfacingright == true)
    //        //{
    //            GameObject.Instantiate(bullet, transform.position, transform.rotation);
    //            Physics2D.IgnoreCollision(bullet.GetComponent<Collider2D>(), GetComponent<Collider2D>());
    //           // GameObject.FindGameObjectWithTag("bullet").transform.Translate(Vector3.right * bulletspeed * Time.deltaTime);
        //    }
        //}
        
       //   else if (Input.GetKeyDown(KeyCode.A))
       //     {
       //// if (pcfcingleft == true)
       //     { 
       //             GameObject.Instantiate(bullet, transform.position, transform.rotation);
       //         Physics2D.IgnoreCollision(bullet.GetComponent<Collider2D>(), GetComponent<Collider2D>());
               // GameObject.FindGameObjectWithTag("bullet").transform.Translate(Vector3.left * bulletspeed * Time.deltaTime);
        //    }
        //}
   // }
    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.name == "platform")
        {
            canjump = true;
        }
    }
}
