﻿using UnityEngine;
using System.Collections;

public class newbulletmove : MonoBehaviour
{
    public Rigidbody2D bullet;
    public float bulletspeed;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.A))
        {
            
            Rigidbody2D bulletInstance=Instantiate(bullet,transform.position,Quaternion.Euler(new Vector3(0,0,0)))as Rigidbody2D;
            bulletInstance.transform.Translate(transform.forward*bulletspeed);
        }
    }
}
