﻿using UnityEngine;
using System.Collections;

public class MU_enemybulletmove : MonoBehaviour
{
    public float bulletspeed;
    public GameObject pc;
    // Use this for initialization
    void Start()
    {
        pc = GameObject.Find("pc");
    }

    // Update is called once per frame
    void Update()
    {
        if (pc.transform.position.x - this.transform.position.x < MU_AInpc.attackdist)
        {
           // pcistotheright = true;
            this.transform.Translate(Vector3.right * bulletspeed);
        }
        if (this.transform.position.x + pc.transform.position.x < MU_AInpc.attackdist)
        {
            //pcistotheleft = true;
            this.transform.Translate(Vector3.left * bulletspeed);
        }
        //if(==true)
        //{
        //    transform.Translate(Vector3.right * bulletspeed);
        //}
        //if(MU_AInpc.pcistotheleft)
        //{
        //    transform.Translate(Vector3.left * bulletspeed);
        //}      
    }
}
