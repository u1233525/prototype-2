﻿using UnityEngine;
using System.Collections;

public class mu_bulletmove : MonoBehaviour
{
   // private mu_pcmove pcscriptinstance;
    public float bulletspeed;
    public bool onlygoleft=false;
    public bool onlygoright=false;
    // Use this for initialization
    void Start()
    {
        if(mu_pcmove.directionfacing==1)
        {
            onlygoleft = true;
        }
        else if(mu_pcmove.directionfacing==2)
        {
            onlygoright = true;
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        
        if(onlygoleft==true)
        {
            this.transform.Translate(Vector3.left * bulletspeed);
        }
        else if(onlygoright==true)
        {
            this.transform.Translate(Vector3.right * bulletspeed);
        }








       // //if(Input.GetKeyDown(KeyCode.A))
       // //{
       // //    if(pcscriptinstance.pcfacingright==true)
       // //    {
       //         this.transform.Translate(Vector3.right * bulletspeed);
       ////     }
       //// }
       ////else if (Input.GetKeyDown(KeyCode.A))
       //// {
       ////     if (pcscriptinstance.pcfcingleft == true)
       ////     {
       ////         this.transform.Translate(Vector3.left * bulletspeed);
       ////     }
       //// }


       // //if (pcscriptinstance.pcfacingright == true && Input.GetKey(KeyCode.A))
       // //{
       // //    this.transform.Translate(Vector3.right * bulletspeed);
       // //    //if (pcscriptinstance.pcfcingleft == true)
       // //    //{
       // //    //    this.transform.Translate(Vector3.right * bulletspeed);
       // //    //}
       // //}
       // //else if (pcscriptinstance.pcfcingleft == true && Input.GetKey(KeyCode.A))
       // //{
       // //    this.transform.Translate(Vector3.left * bulletspeed);
       // //    //if(pcscriptinstance.pcfacingright==true)
       // //    //{
       // //    //    this.transform.Translate(Vector3.left * bulletspeed);
       // //    //}
       // //}
        Destroy(this.gameObject, 2f);
    }

}
