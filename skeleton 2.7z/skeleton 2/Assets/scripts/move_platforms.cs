﻿using UnityEngine;
using System.Collections;

public class move_platforms : MonoBehaviour
{
    public float downwardspeed;// the speed at which it is moving up
    public float upwardspeed;// the speed platforms move down
    public float originalyposition;// the original y position of the platform
    public float distancebeimgmoved;// the distance the platform is moving before changing direction

    // Use this for initialization
    void Start()
    {
        originalyposition = this.transform.position.y;// sets y position of the platform to original y position
        //upwardspeed = 9.0f;
        downwardspeed = -upwardspeed;// sets the speed platform moves downwards the same as upwards speed

    }

    // Update is called once per frame
    void Update()// called every frame
    {
        if (originalyposition - transform.position.y > distancebeimgmoved)// if the difference between the original y position is greater then 10
        {
            downwardspeed = upwardspeed;// flip direction.
        }
        else if (originalyposition - transform.position.y < -distancebeimgmoved)// if the difference between the original y position is less then -10
        {
            downwardspeed = -upwardspeed;// flip direction.
        }
        transform.Translate(0, downwardspeed * Time.deltaTime, 0);// actually updating the position of the platforms along the axis.
    }
}
